from __future__ import print_function
import warnings
import math
import torch
from dataset_prep import Dataset_MMD
from torch.utils.data import DataLoader
from torch import nn, optim
from net.model import Model
from Loss import custom_loss_function
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score
import numpy as np
import pandas as pd
import os

# Global Parameters
L2_DECAY = 1e-4
TRAIN_EPOCHS = 100
LEARNING_RATE = 0.001
DROP = 0.5
EPOCHS_DROP = 20.0

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f'Using device: {device}')

def train_ddcnet(epoch, model, learning_rate, source_loader, drop, epochs_drop, loss_param, alpha=0.5, beta=0.3):
    log_interval = 1
    optimizer = optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=L2_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=TRAIN_EPOCHS // 3, T_mult=2, eta_min=1e-6)
    max_grad_norm = 1.0

    model.train()
    train_loss = 0
    TP, TN, FP, FN = 0, 0, 0, 0
    tr_auc_y_gt, tr_auc_y_pred = [], []

    len_dataloader = len(source_loader)
    for step, source_sample_batch in enumerate(source_loader):
        optimizer.zero_grad(set_to_none=True)
        source_data_batch = source_sample_batch['data'].to(device).float()
        source_label_batch = source_sample_batch['label'].to(device).float()

        with torch.cuda.amp.autocast(enabled=True):
            avg_output, group_outputs = model(source_data_batch)
            loss = custom_loss_function(avg_output, group_outputs, source_label_batch, loss_param, alpha, beta)

        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        optimizer.step()
        current_lr = optimizer.param_groups[0]['lr']
        scheduler.step(epoch + step / len_dataloader)

        train_loss += loss.item()
        source_pred_cpu = (torch.sigmoid(avg_output[:, 0]).detach().cpu().numpy() > 0.5).astype(int)
        source_labels_cpu = source_label_batch.cpu().numpy()
        TP += np.sum(np.logical_and(source_pred_cpu == 1, source_labels_cpu == 1))
        TN += np.sum(np.logical_and(source_pred_cpu == 0, source_labels_cpu == 0))
        FP += np.sum(np.logical_and(source_pred_cpu == 1, source_labels_cpu == 0))
        FN += np.sum(np.logical_and(source_pred_cpu == 0, source_labels_cpu == 1))

        tr_auc_y_gt.extend(source_labels_cpu)
        tr_auc_y_pred.extend(torch.sigmoid(avg_output[:, 0]).detach().cpu().numpy())

        if (step + 1) % log_interval == 0:
            print(f"Epoch [{epoch}/{TRAIN_EPOCHS}] Step [{step + 1}/{len_dataloader}]: "
                  f"Loss={loss.item():.6f} lr={current_lr:.6f} "
                  f"(loss_param={loss_param}, alpha={alpha:.2f}, beta={beta:.2f})")

    train_acc = (TP + TN) / (TP + FP + TN + FN)
    train_AUC = roc_auc_score(tr_auc_y_gt, tr_auc_y_pred)
    train_precision = precision_score(tr_auc_y_gt, (np.array(tr_auc_y_pred) > 0.5).astype(int), zero_division=1)
    train_recall = recall_score(tr_auc_y_gt, (np.array(tr_auc_y_pred) > 0.5).astype(int), zero_division=1)
    train_f1 = f1_score(tr_auc_y_gt, (np.array(tr_auc_y_pred) > 0.5).astype(int), zero_division=1)

    print(f'Training Set: Average Loss: {train_loss / len_dataloader:.4f}, Accuracy: {train_acc:.4f}, '
          f'Train AUC: {train_AUC:.5f}, Precision: {train_precision:.4f}, '
          f'Recall: {train_recall:.4f}, F1 Score: {train_f1:.4f}')

    return train_loss / len_dataloader, train_acc, train_precision, train_recall, train_f1

def test_ddcnet(model, target_loader, loss_param, alpha=0.5, beta=0.3):
    model.eval()
    test_loss = 0
    TP, TN, FP, FN = 0, 0, 0, 0
    te_auc_y_gt, te_auc_y_pred = [], []

    with torch.no_grad():
        for test_sample_batch in target_loader:
            test_data_batch = test_sample_batch['data'].to(device).float()
            test_label_batch = test_sample_batch['label'].to(device).float()
            avg_output, group_outputs = model(test_data_batch)
            loss = custom_loss_function(avg_output, group_outputs, test_label_batch, loss_param, alpha, beta)
            test_loss += loss.item()

            test_pred_cpu = (torch.sigmoid(avg_output[:, 0]).detach().cpu().numpy() > 0.5).astype(int)
            test_labels_cpu = test_label_batch.cpu().numpy()
            TP += np.sum(np.logical_and(test_pred_cpu == 1, test_labels_cpu == 1))
            TN += np.sum(np.logical_and(test_pred_cpu == 0, test_labels_cpu == 0))
            FP += np.sum(np.logical_and(test_pred_cpu == 1, test_labels_cpu == 0))
            FN += np.sum(np.logical_and(test_pred_cpu == 0, test_labels_cpu == 1))

            te_auc_y_gt.extend(test_labels_cpu)
            te_auc_y_pred.extend(torch.sigmoid(avg_output[:, 0]).detach().cpu().numpy())

    test_acc = (TP + TN) / (TP + FP + TN + FN)
    test_AUC = roc_auc_score(te_auc_y_gt, te_auc_y_pred)
    test_precision = precision_score(te_auc_y_gt, (np.array(te_auc_y_pred) > 0.5).astype(int), zero_division=1)
    test_recall = recall_score(te_auc_y_gt, (np.array(te_auc_y_pred) > 0.5).astype(int), zero_division=1)
    test_f1 = f1_score(te_auc_y_gt, (np.array(te_auc_y_pred) > 0.5).astype(int), zero_division=1)

    print(f'Test Set: Average Loss: {test_loss / len(target_loader):.4f}, Accuracy: {test_acc:.4f}, AUC: {test_AUC:.5f}, '
          f'Precision: {test_precision:.4f}, Recall: {test_recall:.4f}, F1 Score: {test_f1:.4f}')

    return {
        'test_loss': test_loss / len(target_loader),
        'test_acc': test_acc,
        'test_AUC': test_AUC,
        'test_precision': test_precision,
        'test_recall': test_recall,
        'test_f1': test_f1,
        'y_true': te_auc_y_gt,
        'y_score': te_auc_y_pred
    }

def k_fold_cross_validation(k, data_path, batch_size, loss_param, alpha=0.5, beta=0.3):
    # Set unified save directory
    AUC_SAVE_ROOT = '../codes/site实验/site25/AUC'
    os.makedirs(AUC_SAVE_ROOT, exist_ok=True)

    for fold in range(k):
        print(f'Fold {fold + 1}/{k} started...')
        current_data_path = os.path.join(data_path, f'dataset_{fold + 1}')

        # Load data
        train_data = np.load(os.path.join(current_data_path, 'src_data.npy'))
        train_labels = np.load(os.path.join(current_data_path, 'src_lbl.npy'))
        test_data = np.load(os.path.join(current_data_path, 'tgt_data.npy'))
        test_labels = np.load(os.path.join(current_data_path, 'tgt_lbl.npy'))

        train_dataset = Dataset_MMD(train_data, train_labels)
        test_dataset = Dataset_MMD(test_data, test_labels)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, drop_last=True)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, drop_last=False)

        model = Model(in_channels=1, num_class=1, edge_importance_weighting=True, root_path=current_data_path)
        model.to(device)

        for epoch in range(1, TRAIN_EPOCHS + 1):
            print(f'Training Epoch {epoch}:')
            train_ddcnet(epoch, model, LEARNING_RATE, train_loader, DROP, EPOCHS_DROP, loss_param, alpha, beta)
            test_results = test_ddcnet(model, test_loader, loss_param, alpha, beta)

            # Save prediction results for current epoch
            epoch_auc_str = f"{test_results['test_AUC']:.4f}"
            epoch_output_df = pd.DataFrame({
                'y_true': test_results['y_true'],
                'y_score': test_results['y_score']
            })
            epoch_filename = f'results_fold{fold + 1}_auc_{epoch_auc_str}.xlsx'
            epoch_filepath = os.path.join(AUC_SAVE_ROOT, epoch_filename)
            epoch_output_df.to_excel(epoch_filepath, index=False)

            if hasattr(model, 'reset_dynamic_state'):
                model.reset_dynamic_state()

    print(f"Prediction results for all epochs have been saved to: {AUC_SAVE_ROOT}")
    return [], {}


def run_multiple_k_fold(k, times, data_path, save_path, excel_name, batch_sizes, loss_param=0.1, alpha=0.5, beta=0.3):
    all_results = []
    all_summaries = []
    for batch_size in batch_sizes:
        for i in range(times):
            print(f"\n=========== batch_size: {batch_size}, {k}-fold cross validation {i+1} started ===========")
            results, summary = k_fold_cross_validation(
                k=k,
                data_path=data_path,
                batch_size=batch_size,
                loss_param=loss_param,
                alpha=alpha,
                beta=beta
            )
            for res in results:
                res['batch_size'] = batch_size
            all_results.extend(results)
            summary_df = pd.DataFrame(summary).T
            summary_df['batch_size'] = batch_size
            all_summaries.append(summary_df)

    os.makedirs(save_path, exist_ok=True)
    excel_path = os.path.join(save_path, excel_name)

    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        pd.DataFrame(all_results).to_excel(writer, sheet_name='All_Results', index=False)
        pd.concat(all_summaries, ignore_index=True).to_excel(writer, sheet_name='Summaries', index=False)

    print(f"All experimental results and statistics have been saved to different sheets in '{excel_name}'")
