import torch
import torch.nn as nn
import numpy as np
import codes.mmd as mmd
from codes.net.utils.tgcn import ConvTemporalGraphical
from TripletAttention import TripletAttention

class Model(nn.Module):
    r"""Spatial temporal graph convolutional networks.  时间-空间图卷积网络

    Args:参数
        in_channels (int): Number of channels in the input data  输入数据的通道数，即每个节点特征维度
        num_class (int): Number of classes for the classification task  分类任务的类别数--2
        edge_importance_weighting (bool): If ``True``, adds a learnable
            importance weighting to the edges of the graph  布尔值，指示是否为图的边添加可学习的重要性权重
        **kwargs (optional): Other parameters for graph convolution units

    Shape:维度
        - Input: :math:`(N, in_channels, T_{in}, V_{in}, M_{in})`
        - Output: :math:`(N, num_class)` where torch.nn
            :math:`N` is batch size, 批量大小
            :math:`T_{in}` is a length of input sequence, 输入序列的长度
            :math:`V_{in}` is the number of graph nodes,  图中节点的数量
            :math:`M_{in}` is the number of instance in a frame.   每帧中实例的数量
    """

    # ->object 指定函数返回值类型
    def __init__(self, in_channels, num_class, edge_importance_weighting, **kwargs) -> object:
        super().__init__()

        A = np.load('../data/adj_matrix.npy')
        # 邻接矩阵A的每一列之和，得到每个节点的度数(即与该节点相连边的数量)
        Dl = np.sum(A, 0)

        # 获得节点数量
        num_node = A.shape[0]
        # 初始化一个num_node*num_node的零矩阵
        Dn = np.zeros((num_node, num_node))
        # Dn 最后得到一个是对角矩阵
        for i in range(num_node):
            if Dl[i] > 0:
                Dn[i, i] = Dl[i] ** (-0.5)  # 计算每一个节点度的倒数的平方根，得到每个节点的归一化因子

        # 计算对称归一化拉普拉斯矩阵DAD
        DAD = np.dot(np.dot(Dn, A), Dn)

        # 构建了一个全零的三维数组，第一个维度的大小为1，第二个维度的大小为节点数量，第三个维度的大小为节点数量
        temp_matrix = np.zeros((1, A.shape[0], A.shape[0]))
        # 将DAD放在了temp_matrix的第一个维度上
        temp_matrix[0] = DAD

        # 将temp_matrix转换成tensor，数据格式为float32，并注册为buffer缓冲区
        # requires_grad=False表示不需要计算梯度, 因为DAD是固定不变的 A = 1*N*N
        A = torch.tensor(temp_matrix, dtype=torch.float32, requires_grad=False)
        self.register_buffer('A', A)

        # 构建神经网络，共四层，输出特征数为16，卷积核kernel size大小为(11, 1)
        spatial_kernel_size = A.size(0)  # spatial_kernel_size 空间核的大小=1
        temporal_kernel_size = 11  # 设置temporal_kernel_size的大小为11，在时间维度上进行卷积操作
        kernel_size = (temporal_kernel_size, spatial_kernel_size)  # kernel_size = (11, 1)

        # 构建批量归一化层，对输入数据进行归一化处理  in_channels 是每一个节点中的特征维度
        self.data_bn = nn.BatchNorm1d(in_channels * A.size(1))

        # 除去"dropout",重新建立一个字典序
        kwargs0 = {k: v for k, v in kwargs.items() if k != 'dropout'}  # kwargs0: {}

        # 构建空间-时间卷积层  不采用残差连接
        self.st_gcn_networks = nn.ModuleList((
            st_gcn(in_channels, 16, kernel_size, 1, residual=False, **kwargs0),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
        ))

        # 构建注意力机制层
        self.triplet_attention = TripletAttention()

        # 初始化边权重的参数
        if edge_importance_weighting:
            self.edge_importance = nn.ParameterList([
                nn.Parameter(torch.ones(self.A.size()))
                for i in self.st_gcn_networks
            ])    # 边权重参数列表，每个元素都是一张全1的tensor，大小为(1, N, N) 为每一个图卷积曾都创建一个nn.parameter
        else:  # 如果不使用边权重，则初始化为1
            self.edge_importance = [1] * len(self.st_gcn_networks)

        # 创建分类卷积层
        self.cls_fcn1 = nn.Conv2d(3200, 1024, kernel_size=1)
        self.cls_fcn2 = nn.Conv2d(1024, 512, kernel_size=1)
        self.cls_fcn3 = nn.Conv2d(512, 64, kernel_size=1)
        self.cls_fcn4 = nn.Conv2d(64, num_class, kernel_size=1)
        self.sig = nn.Sigmoid()

    def forward(self, source, target):

        # N batch_size, C 通道数， T 时间序列长度， V 节点数量， M 是每帧的实例数
        N, C, T, V, M = source.size()  # (bs, 1, T, NodeNum, 1)
        # permute 重新排列张量的维度   contiguous 确保张量在内存中连续
        # 0，4，3，1，2 表示将输入数据进行维度转换，将N，M，C，T，V 转换为 N，M，V，C，T
        source = source.permute(0, 4, 3, 1, 2).contiguous()
        # view是重塑张量的形状，而不改变数据  就是一个reshape
        source = source.view(N * M, V * C, T)
        source = self.data_bn(source.float())

        source = source.view(N, M, V, C, T)
        source = source.permute(0, 1, 3, 4, 2).contiguous()
        source = source.view(N * M, C, T, V)

        # 将source应用在每一层上，每层都考虑边的重要权重
        for gcn, importance in zip(self.st_gcn_networks, self.edge_importance):
            source, _ = gcn(source, self.A * importance)

        #  应用注意力机制
        N, C, T, V =target.size()
        source = source.permute(0, 2, 1, 3).contiguous()  # (N, T, C, V)
        source = self.triplet_attention(source)  # (N, T, C, V)
        source = source.permute(0, 2, 1, 3).contiguous()  # (N, C, T, V)

        # 沿着axis=3对每一个节点的特征进行平均
        source = source.mean(axis=3)
        # 重塑为(N, M*V*C)
        source = source.view(source.size(0), -1)

        #  分类层
        # 重塑张量 往最后添加两个维度，分别是1和1，即(N,M, V*C, 1, 1)，沿着第二个维度取平均得到
        source_0 = source.view(N, M, -1, 1, 1).mean(dim=1)
        source_1 = self.cls_fcn1(source_0)
        source_2 = self.cls_fcn2(source_1)
        source_3 = self.cls_fcn3(source_2)
        source_4 = self.cls_fcn4(source_3)
        source_5 = self.sig(source_4)

        # 计算MMD损失
        mmd_loss = 0
        if self.training:
            N, C, T, V, M = target.size()
            target = target.permute(0, 4, 3, 1, 2).contiguous()
            target = target.view(N * M, V * C, T)
            target = self.data_bn(target.float())
            target = target.view(N, M, V, C, T)
            target = target.permute(0, 1, 3, 4, 2).contiguous()
            target = target.view(N * M, C, T, V)

            for gcn, importance in zip(self.st_gcn_networks, self.edge_importance):
                target, _ = gcn(target, self.A * importance)

            target = target.mean(axis=3)
            target = target.view(target.size(0), -1)

            #  预测
            target_0 = target.view(N, M, -1, 1, 1).mean(dim=1)
            target_1 = self.cls_fcn1(target_0)
            target_2 = self.cls_fcn2(target_1)
            target_3 = self.cls_fcn3(target_2)
            target_4 = self.cls_fcn4(target_3)
            target_5 = self.sig(target_4)

            # linear mmd
            mmd_loss += (mmd.mmd_linear(source_1.squeeze(), target_1.squeeze()) + mmd.mmd_linear(source_2.squeeze(),
                                                                                                 target_2.squeeze()) + mmd.mmd_linear(
                source_3.squeeze(), target_3.squeeze()))

        result = source_5.view(source_5.size(0), -1)

        return result, mmd_loss


class st_gcn(nn.Module):
    r"""Applies a spatial temporal graph convolution over an input graph sequence.

    Args:
        in_channels (int): Number of channels in the input sequence data  输入的通道数
        out_channels (int): Number of channels produced by the convolution  通过卷积操作后的输出通道数
        kernel_size (tuple): Size of the temporal convolving kernel and graph convolving kernel  时间卷积核大小和图卷积核大小
        stride (int, optional): Stride of the temporal convolution. Default: 1  时间卷积的步长
        dropout (int, optional): Dropout rate of the final output. Default: 0    输出的dropout率
        residual (bool, optional): If ``True``, applies a residual mechanism. Default: ``True``  布尔值，指示是否使用残差机制

    Shape:
        - Input[0]: Input graph sequence in :math:`(N, in_channels, T_{in}, V)` format
        - Input[1]: Input graph adjacency matrix in :math:`(K, V, V)` format
        - Output[0]: Output graph sequence in :math:`(N, out_channels, T_{out}, V)` format
        - Output[1]: Graph adjacency matrix for output data in :math:`(K, V, V)` format

        where
            :math:`N` is batch size,  批量大小
            :math:`K` is the spatial kernel size, as :math:`K == kernel_size[1]`, 时空卷积核的大小
            :math:`T_{in}/T_{out}` is a length of input/output sequence,  输出序列的长度
            :math:`V` is the number of graph nodes.  节点数量

    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,  # (11, 1)
                 stride=1,
                 dropout=0.5,
                 residual=True):
        super().__init__()
        # print("Dropout={}".format(dropout))
        assert len(kernel_size) == 2   # 确保kernel_size是一个包含两个元素的元组
        assert kernel_size[0] % 2 == 1  # 确保时间卷积核的大小是奇数
        # padding保证在输入数据的边缘周围添加额外的像素值
        padding = ((kernel_size[0] - 1) // 2, 0)  # padding = (5, 0)

        # 构建空间/图卷积层
        self.gcn = ConvTemporalGraphical(in_channels, out_channels, kernel_size[1])  # kernel_size[1] = 1

        # 构建时间卷积层
        self.tcn = nn.Sequential(
            nn.BatchNorm2d(out_channels),  # 对输出通道数进行归一化处理
            nn.ReLU(inplace=True),  # 应用relu激活函数，并且直接对原数据进行修改
            nn.Conv2d(
                # 2D卷积层，输入通道数为out_channels，输出通道数为out_channels，卷积核大小为(kernel_size[0], 1)，步长为(stride,
                # 1)，padding为padding
                out_channels,
                out_channels,
                (kernel_size[0], 1),  # kernel_size[0] = 11
                (stride, 1),
                padding,
            ),
            nn.BatchNorm2d(out_channels),
            nn.Dropout(dropout, inplace=True),
        )

        # 添加TripletAttention层
        self.triplet_attention = TripletAttention()

        if not residual:
            self.residual = lambda x: 0  # 不适用残差

        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x  # 输入通道数等于输出通道数且步长为1，即直接传递输入数据X本身

        else:
            #  1x1 卷积和批归一化实现残差连接
            self.residual = nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    out_channels,
                    kernel_size=1,
                    stride=(stride, 1)),
                nn.BatchNorm2d(out_channels),
            )

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x, A):
        res = self.residual(x)
        x, A = self.gcn(x, A)
        x = self.tcn(x)

        # 应用Triplet Attention
        N, C, T, V = x.size()
        x = x.permute(0, 2, 1, 3).contiguous()  # (N, T, C, V)
        x = self.triplet_attention(x)
        x = x.permute(0, 2, 1, 3).contiguous()  # (N, C, T, V)

        x = x + res
        return self.relu(x), A


class pre_Model(nn.Module):
    r"""Spatial temporal graph convolutional networks.

    Args:
        in_channels (int): Number of channels in the input data
        num_class (int): Number of classes for the classification task
        edge_importance_weighting (bool): If ``True``, adds a learnable
            importance weighting to the edges of the graph
        **kwargs (optional): Other parameters for graph convolution units

    Shape:
        - Input: :math:`(N, in_channels, T_{in}, V_{in}, M_{in})`
        - Output: :math:`(N, num_class)` where torch.nn
            :math:`N` is batch size,
            :math:`T_{in}` is a length of input sequence,
            :math:`V_{in}` is the number of graph nodes,
            :math:`M_{in}` is the number of instance in a frame.
    """

    def __init__(self, in_channels, num_class, edge_importance_weighting, **kwargs) -> object:
        super().__init__()
        A = np.load('../data/adj_matrix.npy')

        Dl = np.sum(A, 0)
        num_node = A.shape[0]
        Dn = np.zeros((num_node, num_node))
        for i in range(num_node):
            if Dl[i] > 0:
                Dn[i, i] = Dl[i] ** (-0.5)
        DAD = np.dot(np.dot(Dn, A), Dn)

        temp_matrix = np.zeros((1, A.shape[0], A.shape[0]))
        temp_matrix[0] = DAD
        A = torch.tensor(temp_matrix, dtype=torch.float32, requires_grad=False)
        self.register_buffer('A', A)

        # build networks (number of layers, final output features, kernel size)
        spatial_kernel_size = A.size(0)
        temporal_kernel_size = 11
        kernel_size = (temporal_kernel_size, spatial_kernel_size)
        self.data_bn = nn.BatchNorm1d(in_channels * A.size(1))
        kwargs0 = {k: v for k, v in kwargs.items() if k != 'dropout'}  # kwargs0: {}
        self.st_gcn_networks = nn.ModuleList((
            st_gcn(in_channels, 16, kernel_size, 1, residual=False, **kwargs0),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
            st_gcn(16, 16, kernel_size, 1, residual=False, **kwargs),
        ))

        # initialize parameters for edge importance weighting
        if edge_importance_weighting:
            self.edge_importance = nn.ParameterList([
                nn.Parameter(torch.ones(self.A.size()))
                for i in self.st_gcn_networks
            ])
        else:
            self.edge_importance = [1] * len(self.st_gcn_networks)

        self.cls_fcn1 = nn.Conv2d(3200, 1024, kernel_size=1)
        self.cls_fcn2 = nn.Conv2d(1024, 512, kernel_size=1)
        self.cls_fcn3 = nn.Conv2d(512, 64, kernel_size=1)
        self.cls_fcn4 = nn.Conv2d(64, num_class, kernel_size=1)
        self.sig = nn.Sigmoid()

    def forward(self, source):

        N, C, T, V, M = source.size()
        source = source.permute(0, 4, 3, 1, 2).contiguous()
        source = source.view(N * M, V * C, T)
        source = self.data_bn(source.float())
        source = source.view(N, M, V, C, T)
        source = source.permute(0, 1, 3, 4, 2).contiguous()
        source = source.view(N * M, C, T, V)

        for gcn, importance in zip(self.st_gcn_networks, self.edge_importance):
            source, _ = gcn(source, self.A * importance)

        source = source.mean(axis=3)
        source = source.view(source.size(0), -1)

        #  prediction
        source = source.view(N, M, -1, 1, 1).mean(dim=1)
        source = self.cls_fcn1(source)
        source = self.cls_fcn2(source)
        source = self.cls_fcn3(source)
        source = self.cls_fcn4(source)
        source = self.sig(source)
        result = source.view(source.size(0), -1)

        return result
