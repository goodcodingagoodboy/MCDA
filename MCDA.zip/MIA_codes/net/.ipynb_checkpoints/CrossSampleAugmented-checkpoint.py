import torch
import torch.nn as nn


# 定义基础卷积块
class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True,
                 bn=True, bias=False):
        super(BasicConv, self).__init__()
        # 设置输出通道数
        self.out_channels = out_planes
        # 创建一个二维卷积层
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding,
                              dilation=dilation, groups=groups, bias=bias)
        # 如果使用批归一化，则创建一个批归一化层
        self.bn = nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True) if bn else None
        # 如果使用ReLU激活函数，则创建一个ReLU层
        self.relu = nn.ReLU() if relu else None

    def forward(self, x):
        # 执行卷积操作
        x = self.conv(x)
        # 如果有批归一化层，则执行批归一化
        if self.bn is not None:
            x = self.bn(x)
        # 如果有ReLU激活函数，则应用ReLU激活
        if self.relu is not None:
            x = self.relu(x)
        return x


# 定义ZPool池化模块
class ZPool(nn.Module):
    def forward(self, x):
        # 对输入张量在第0维度（通常是batch B）上进行全局最大池化
        a = torch.max(x, 0, keepdim=True)[0]  # 保持batch维度
        # 对输入张量在第0维度（通常是batch B）上进行全局平均池化
        b = torch.mean(x, 0, keepdim=True)  # 保持batch维度
        # 将最大池化和平均池化的结果沿着通道维度拼接起来
        c = torch.cat((a, b), dim=1)
        return c


# 定义注意力门控模块
class AttentionGate(nn.Module):
    def __init__(self):
        super(AttentionGate, self).__init__()
        # 定义卷积核大小
        kernel_size = 7
        # 使用ZPool进行池化操作
        self.compress = ZPool()
        # 创建一个基本的卷积块，用于处理池化后的特征图
        self.conv = BasicConv(2, 1, kernel_size, stride=1, padding=(kernel_size - 1) // 2, relu=False)

    def forward(self, x):
        # 对输入张量进行压缩（池化并拼接）
        x_compress = self.compress(x)
        # 对压缩后的特征图进行卷积操作
        x_out = self.conv(x_compress)
        # 使用Sigmoid函数生成注意力权重
        scale = torch.sigmoid_(x_out)
        # 根据注意力权重对原始输入张量进行加权
        return x * scale


# 定义跨样本增强模块
class CrossSampleAugmented(nn.Module):
    def __init__(self, no_spatial=False):
        super(CrossSampleAugmented, self).__init__()
        # 高度与通道的交互
        self.hc = AttentionGate()

    def forward(self, x):
        # (B, C, H, W) -> (C, B, H, W)，建立batch B与通道C之间的交互
        x_perm = x.permute(1, 0, 2, 3).contiguous()
        # 在B维度上进行池化、拼接、卷积、sigmoid操作并加权
        x_out = self.hc(x_perm)
        # 还原到原始维度：(C, B, H, W) -> (B, C, H, W)
        x_out = x_out.permute(1, 0, 2, 3).contiguous()

        return x_out


# 测试模型
# if __name__ == '__main__':
#     # 创建随机输入数据，形状为 (batch_size, channels, height, width)
#     input = torch.randn(1, 512, 7, 7)
#     # 实例化模型
#     model = CrossSampleAugmented()
#     # 前向传播
#     output = model(input)
#     # 输出结果的形状
#     print(output.shape)  # 应该输出: torch.Size([1, 512, 7, 7])