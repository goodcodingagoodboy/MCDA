# The based unit of graph convolutional networks.
import torch
import torch.nn as nn
from TripletAttention import TripletAttention

class ConvTemporalGraphical(nn.Module):

    r"""The basic module for applying a graph convolution. 图卷积

    Args:
        in_channels (int): Number of c

        hannels in the input sequence data  输入数据的通道数
        out_channels (int): Number of channels produced by the convolution   卷积后输出的数据通道数
        kernel_size (int): Size of the graph convolving kernel   图卷积核的大小
        t_kernel_size (int): Size of the temporal convolving kernel   时间卷积核的大小
        t_stride (int, optional): Stride of the temporal convolution. Default: 1   时间卷积的步长
        t_padding (int, optional): Temporal zero-padding added to both sides of
            the input. Default: 0   时间卷积的零填充
        t_dilation (int, optional): Spacing between temporal kernel elements.
            Default: 1   时间卷积的膨胀率，当为1时，表示没有膨胀
        bias (bool, optional): If ``True``, adds a learnable bias to the output.
            Default: ``True``  是否添加可学习的偏置，默认值位"True"

    Shape:
        - Input[0]: Input graph sequence in :math:`(N, in_channels, T_{in}, V)` format
        - Input[1]: Input graph adjacency matrix in :math:`(K, V, V)` format
        - Output[0]: Output graph sequence in :math:`(N, out_channels, T_{out}, V)` format
        - Output[1]: Graph adjacency matrix for output data in :math:`(K, V, V)` format

        where
            :math:`N` is a batch size,  批量大小
            :math:`K` is the spatial kernel size, as :math:`K == kernel_size[1]`, 空间卷积核的大小
            :math:`T_{in}/T_{out}` is a length of input/output sequence,   输入/输出序列的长度
            :math:`V` is the number of graph nodes.   图中节点的数量
    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,  # kernel_size = 1 这里是图卷积/空间卷积核的大小
                 t_kernel_size=1,  # 时间卷积核的大小
                 t_stride=1,
                 t_padding=0,
                 t_dilation=1,
                 bias=True):
        super().__init__()

        self.kernel_size = kernel_size
        self.conv = nn.Conv2d(
            in_channels,
            out_channels * kernel_size,
            kernel_size=(t_kernel_size, 1),
            padding=(t_padding, 0),
            stride=(t_stride, 1),
            dilation=(t_dilation, 1),
            bias=bias)

        self.triplet_attention = TripletAttention()

    def forward(self, x, A):  # x.shape: torch.Size([64, 64, 128, 22])
        assert A.size(0) == self.kernel_size
        x = self.conv(x)  # torch.Size([64, 64, 128, 22])  see as: N*C*H*W
        n, kc, t, v = x.size()
        x = x.view(n, self.kernel_size, kc//self.kernel_size, t, v)  # torch.Size([64, 1, 64, 128, 22])
        x = torch.einsum('nkctv,kvw->nctw', (x, A))  # torch.Size([64, 64, 128, 22])

        # 应用Triplet Attention
        N, C, T, V = x.size()
        x = x.permute(0, 2, 1, 3).contiguous()  # (N, T, C, V)
        x = self.triplet_attention(x)
        x = x.permute(0, 2, 1, 3).contiguous()  # (N, C, T, V)

        # 这个公式可以理解为根据邻接矩阵中的邻接关系做了一次邻接节点间的特征融合，输出就变回了(N * M, C, T, V) 的格式进入tcn
        return x.contiguous(), A  # x.contiguous().shape: torch.Size([64, 64, 128, 22])

