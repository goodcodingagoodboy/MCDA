import torch
import torch.nn as nn
import numpy as np
import os
from net.utils.tgcn import ConvTemporalGraphical
from net.CrossSampleAugmented import CrossSampleAugmented
from net.SelfAwareAugmented import SelfAwareAugmented
from net.DynamicUpdateBiGRU import DynamicUpdateBiGRU


class Model(nn.Module):
    def __init__(self, in_channels, num_class, edge_importance_weighting, root_path, **kwargs):
        super().__init__()
        self.root_path = root_path

        # === Load graph structure ===
        A = np.load(os.path.join(self.root_path, 'adj_matrix.npy'))
        Dl = np.sum(A, 0)
        num_node = A.shape[0]
        Dn = np.zeros((num_node, num_node))
        for i in range(num_node):
            if Dl[i] > 0:
                Dn[i, i] = Dl[i] ** (-0.5)
        DAD = np.dot(np.dot(Dn, A), Dn)

        temp_matrix = np.zeros((1, A.shape[0], A.shape[0]))
        temp_matrix[0] = DAD
        A = torch.tensor(temp_matrix, dtype=torch.float32, requires_grad=False)
        self.register_buffer('A', A)

        # === Basic parameter settings ===
        spatial_kernel_size = A.size(0)
        temporal_kernel_size = 11
        kernel_size = (temporal_kernel_size, spatial_kernel_size)
        self.data_bn = nn.BatchNorm1d(in_channels * A.size(1))
        kwargs0 = {k: v for k, v in kwargs.items() if k != 'dropout'}

        # === Define three groups of GCN branches ===
        self.st_gcn_networks = nn.ModuleList([
            nn.ModuleList([
                st_gcn(in_channels, 16, kernel_size, 1, residual=False, attention_type='cross_sample', **kwargs0),
                st_gcn(16, 16, kernel_size, 1, residual=False, attention_type='cross_sample', **kwargs),
                st_gcn(16, 16, kernel_size, 1, residual=False, attention_type='cross_sample', **kwargs),
            ]),
            nn.ModuleList([
                st_gcn(in_channels, 16, kernel_size, 1, residual=False, attention_type='original', **kwargs0),
                st_gcn(16, 16, kernel_size, 1, residual=False, attention_type='original', **kwargs),
                st_gcn(16, 16, kernel_size, 1, residual=False, attention_type='original', **kwargs),
            ]),
            nn.ModuleList([
                st_gcn(in_channels, 16, kernel_size, 1, residual=False, attention_type='self_aware', **kwargs0),
                st_gcn(16, 16, kernel_size, 1, residual=False, attention_type='self_aware', **kwargs),
                st_gcn(16, 16, kernel_size, 1, residual=False, attention_type='self_aware', **kwargs),
            ])
        ])

        # === Edge importance weighting ===
        if edge_importance_weighting:
            self.edge_importance = nn.ParameterList([
                nn.Parameter(torch.ones(self.A.size()))
                for _ in self.st_gcn_networks
            ])
        else:
            self.edge_importance = [1] * len(self.st_gcn_networks)

        # === Classification layers ===
        self.cls_fcn1 = nn.Conv2d(3200, 1024, kernel_size=1)
        self.cls_fcn2 = nn.Conv2d(1024, 512, kernel_size=1)
        self.cls_fcn3 = nn.Conv2d(512, 64, kernel_size=1)
        self.cls_fcn4 = nn.Conv2d(64, num_class, kernel_size=1)
        self.sig = nn.Sigmoid()

        # === Dynamic updater lazy initialization ===
        self.dynamic_updater = None
        self.dynamic_updater_initialized = False
        self.current_SA = None
        self.current_CA = None

    def forward(self, source):
        N, C, T, V, M = source.size()
        source = source.permute(0, 4, 3, 1, 2).contiguous().view(N * M, V * C, T)
        source = self.data_bn(source.float()).view(N, M, V, C, T)
        source = source.permute(0, 1, 3, 4, 2).contiguous().view(N * M, C, T, V)

        # === Multi-branch GCN ===
        group_outputs = []
        for gcn_group, importance in zip(self.st_gcn_networks, self.edge_importance):
            group_output = source
            for gcn in gcn_group:
                group_output, _ = gcn(group_output, self.A * importance)
            group_outputs.append(group_output)

        # === First dynamic updater initialization ===
        if self.training:
            if not self.dynamic_updater_initialized:
                C_out, T_out, V_out = group_outputs[2].shape[1:]
                self.dynamic_updater = DynamicUpdateBiGRU(input_shape=(C_out, T_out, V_out), hidden_dim=256).to(group_outputs[2].device)
                self.dynamic_updater_initialized = True

            self.current_SA, self.current_CA = self.dynamic_updater(group_outputs[2], group_outputs[0])
            group_outputs[2] = self.current_SA
            group_outputs[0] = self.current_CA

        # === Classification ===
        output = group_outputs[1].mean(dim=3)  # [N*M, C, T]
        output = output.view(output.size(0), -1, 1, 1)
        x = self.cls_fcn1(output)
        x = self.cls_fcn2(x)
        x = self.cls_fcn3(x)
        x = self.cls_fcn4(x)
        return x.view(x.size(0), -1), group_outputs

    def reset_dynamic_state(self):
        if self.dynamic_updater is not None:
            self.dynamic_updater.reset()
        self.current_SA = None
        self.current_CA = None


class st_gcn(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 kernel_size,
                 stride=1,
                 dropout=0.5,
                 residual=True,
                 attention_type='cross_sample'):
        super().__init__()
        assert len(kernel_size) == 2
        assert kernel_size[0] % 2 == 1
        padding = ((kernel_size[0] - 1) // 2, 0)

        self.gcn = ConvTemporalGraphical(in_channels, out_channels, kernel_size[1])
        self.tcn = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, (kernel_size[0], 1), (stride, 1), padding),
            nn.BatchNorm2d(out_channels),
            nn.Dropout(dropout, inplace=True),
        )

        if attention_type == 'cross_sample':
            self.attention = CrossSampleAugmented()
        elif attention_type == 'original':
            self.attention = None
        elif attention_type == 'self_aware':
            self.attention = SelfAwareAugmented(1)

        if not residual:
            self.residual = lambda x: 0
        elif (in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x
        else:
            self.residual = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=(stride, 1)),
                nn.BatchNorm2d(out_channels),
            )

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x, A):
        res = self.residual(x)
        x, A = self.gcn(x, A)
        x = self.tcn(x)

        if self.attention is not None:
            x = x.permute(0, 2, 1, 3).contiguous()
            x = self.attention(x)
            x = x.permute(0, 2, 1, 3).contiguous()

        x = x + res
        return self.relu(x), A