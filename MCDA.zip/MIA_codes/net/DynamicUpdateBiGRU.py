import torch
import torch.nn as nn

class DynamicUpdateBiGRU(nn.Module):
    def __init__(self, input_shape, hidden_dim=256, num_layers=3):
        """
        Dynamically update augmented views using multi-layer bidirectional GRU.
        Args:
            input_shape (tuple): Shape of the augmented view (C, T, V)
            hidden_dim (int): GRU hidden state dimension
            num_layers (int): Number of GRU layers
        """
        super().__init__()
        self.input_shape = input_shape  # (C, T, V)
        C, T, V = input_shape
        self.input_dim = C * V
        self.T = T
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        # Bidirectional GRU (3 layers)
        self.bigru_SA = nn.GRU(
            input_size=self.input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True
        )
        self.bigru_CA = nn.GRU(
            input_size=self.input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True
        )

        # Bidirectional = 2 * hidden_dim, so decoder outputs input_dim size
        self.decoder_SA = nn.Linear(hidden_dim * 2, self.input_dim)
        self.decoder_CA = nn.Linear(hidden_dim * 2, self.input_dim)

    def forward(self, current_SA, current_CA):
        """
        Input current augmented views, return updated augmented views
        Args:
            current_SA (Tensor): [N, C, T, V]
            current_CA (Tensor): [N, C, T, V]
        Returns:
            updated_SA, updated_CA: Updated views [N, C, T, V]
        """
        N, C, T, V = current_SA.shape

        # Reshape to sequence format accepted by GRU [N, T, C*V]
        SA_seq = current_SA.permute(0, 2, 1, 3).reshape(N, T, -1)
        CA_seq = current_CA.permute(0, 2, 1, 3).reshape(N, T, -1)

        # BiGRU update
        out_SA, _ = self.bigru_SA(SA_seq)
        out_CA, _ = self.bigru_CA(CA_seq)

        # Decode output at each time step
        decoded_SA = self.decoder_SA(out_SA)  # [N, T, C*V]
        decoded_CA = self.decoder_CA(out_CA)

        # Reshape back to original shape [N, C, T, V]
        updated_SA = decoded_SA.reshape(N, T, C, V).permute(0, 2, 1, 3)
        updated_CA = decoded_CA.reshape(N, T, C, V).permute(0, 2, 1, 3)

        return updated_SA, updated_CA
    
    def reset(self):
        """Compatible with old interface, BiGRU does not require explicit hidden state reset."""
        pass