import torch
import torch.nn as nn

def custom_loss_function(avg_output, group_outputs, target, param, alpha=0.5, beta=0.3, return_contrast_loss=False):
    """Custom loss function combining classification cross-entropy loss and feature cosine similarity.
    
    Args:
        avg_output: Classification model output (logits)
        group_outputs: Feature outputs from three networks (three returned features)
        target: Ground truth labels (for classification cross-entropy computation)
        param: Overall weight coefficient for cosine similarity loss
        alpha: Weight controlling similarity between original and self_aware features (default 0.5)
        beta: Weight controlling similarity between cross_sample and self_aware features (default 0.3)
        return_contrast_loss: Whether to return the contrast loss value (default False)
    
    Returns:
        If return_contrast_loss=False:
            Returns total_loss: Combination of classification loss and weighted cosine similarity loss
        If return_contrast_loss=True:
            Returns (total_loss, contrast_loss): Tuple of total loss and contrast loss
    """
    # Ensure target labels are between 0 and 1
    target = torch.clamp(target.view(-1, 1).float(), 0, 1)
    
    # Use BCEWithLogitsLoss, ensuring input is logits rather than sigmoid outputs
    classification_loss = nn.BCEWithLogitsLoss()(avg_output, target)
    
    # Compute cosine similarity among three sets of features
    cross_sample = group_outputs[0]
    original = group_outputs[1]
    self_aware = group_outputs[2]
    
    # Compute cosine similarity between different feature pairs
    cosine_similarity_12 = nn.functional.cosine_similarity(cross_sample, original, dim=1).mean()
    cosine_similarity_13 = nn.functional.cosine_similarity(cross_sample, self_aware, dim=1).mean()
    cosine_similarity_23 = -(nn.functional.cosine_similarity(original, self_aware, dim=1).mean())
    
    # Compute weighted cosine similarity loss using alpha and beta parameters
    contrast_loss = (1 - alpha) * cosine_similarity_12 + beta * cosine_similarity_13 + alpha * cosine_similarity_23
    
    # Compute total loss
    total_loss = classification_loss - param * contrast_loss
    
    if return_contrast_loss:
        return total_loss, contrast_loss
    else:
        return total_loss